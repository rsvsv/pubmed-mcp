@echo off
python -I "%~dp0install.py" --configure both
if errorlevel 1 (
  echo Installation failed. Keep this window output for diagnosis.
  pause
  exit /b 1
)
echo Installation completed. Restart Claude.
pause
